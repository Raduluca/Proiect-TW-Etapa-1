import ProdusCard from "./ProdusCard.jsx";

export default function ProdusList({ produse }) {
  // 1. Verificare pentru listă goală (return timpuriu)
  if (!produse || produse.length === 0) {
    return <p className="empty">Nu există niciun produs în depozit.</p>;
  }

  // 2. Randarea listei cu map și atributul key pe componenta directă
  return (
    <ul className="produs-list">
      {produse.map((produs) => (
        <ProdusCard key={produs.id} produs={produs} />
      ))}
    </ul>
  );
}