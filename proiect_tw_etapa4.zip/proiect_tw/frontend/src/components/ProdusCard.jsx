// Dicționar pentru traducerea tipului de produs pe ecran
const ETICHETE_TIP = {
  "materie-prima": "Materie primă",
  "consumabil": "Consumabil",
  "produs-finit": "Produs finit"
};

export default function ProdusCard({ produs }) {
  const esteDisponibil = produs.disponibil || produs.stoc > 0;

  return (
    <li className={esteDisponibil ? "produs-card" : "produs-card indisponibil"}>
      <div className="produs-info">
        <h3>{produs.nume}</h3>
        <span className={`badge badge-${produs.tip}`}>
          {ETICHETE_TIP[produs.tip] || produs.tip}
        </span>
        <p className="produs-detalii">
          Categorie: {produs.categorie} | Stoc: {produs.stoc} buc.
        </p>
      </div>
      <span className={esteDisponibil ? "status disponibil" : "status indisponibil"}>
        {esteDisponibil ? "Disponibil" : "Indisponibil"}
      </span>
    </li>
  );
}