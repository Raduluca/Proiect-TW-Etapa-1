import ProdusList from "./components/ProdusList.jsx";
import "./App.css";

const produse = [
  {
    id: 1,
    nume: "Șuruburi M8",
    stoc: 3,
    disponibil: true,
    tip: "materie-prima",
    categorie: "Hardware",
    utilizator: "admin"
  },
  {
    id: 2,
    nume: "Cutii de carton",
    stoc: 0,
    disponibil: false,
    tip: "consumabil",
    categorie: "Ambalaje",
    utilizator: "admin"
  },
  {
    id: 3,
    nume: "Motoare electrice",
    stoc: 3,
    disponibil: true,
    tip: "produs-finit",
    categorie: "Electronice",
    utilizator: "admin"
  }
];

export default function App() {
  const disponibile = produse.filter((p) => p.disponibil || p.stoc > 0).length;

  return (
    <>
      <header className="app-header">
        <h1>DepoTrack</h1>
        <p>Gestionarea stocurilor și produselor din depozit.</p>
        <p className="app-count">
          {produse.length} produse, dintre care {disponibile} disponibile
        </p>
      </header>

      <main className="container">
        <section className="panel">
          <h2>Produsele din depozit</h2>
          <ProdusList produse={produse} />
        </section>
      </main>
    </>
  );
}