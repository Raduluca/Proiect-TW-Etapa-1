
const TIPURI_PRODUSE = [
    "materie-prima",
    "produs-finit",
    "consumabil"
];

// Datele initiale ale depozitului
const produse = [
    {
        id: 1,
        nume: "Șuruburi M8",
        stoc: 3,
        disponibil: true,
        tip: "materie-prima",
        categorie: "Hardware",
        utilizator: "admin"
    },
    {
        id: 2,
        nume: "Cutii de carton",
        stoc: 0,
        disponibil: false,
        tip: "consumabil",
        categorie: "Ambalaje",
        utilizator: "admin"
    },
    {
        id: 3,
        nume: "Motoare electrice",
        stoc: 3,
        disponibil: true,
        tip: "produs-finit",
        categorie: "Electronice",
        utilizator: "admin"
    }
];

// 1. Listeaza numele produselor
function listeazaProduse(lista) {
    return lista.map(produs => produs.nume);
}

// 2. Numara produsele disponibile
function numaraDisponibile(lista) {
    return lista.filter(produs => produs.stoc > 0).length;
}

// 3. Cauta produse dupa nume
function cautaProduse(lista, text) {
    const cautat = text.trim().toLowerCase();

    if (cautat === "") {
        return [];
    }

    return lista.filter(produs =>
        produs.nume.toLowerCase().includes(cautat)
    );
}

// 4. Calculeaza urmatorul ID
function nextId(lista) {
    return lista.reduce(
        (maxim, produs) => Math.max(maxim, produs.id),
        0
    ) + 1;
}

// 5. Adauga produs cu validare
function adaugaProdus(
    lista,
    nume,
    stoc = 0,
    tip = "materie-prima",
    categorie = "Hardware",
    utilizator = "admin"
) {
    const numeCurat =
        typeof nume === "string" ? nume.trim() : "";

    if (numeCurat === "") {
        console.error("Numele produsului nu poate fi gol.");
        return lista;
    }

    if (!Number.isInteger(stoc) || stoc < 0) {
        console.error("Stocul trebuie sa fie un numar intreg pozitiv sau zero.");
        return lista;
    }

    if (!TIPURI_PRODUSE.includes(tip)) {
        console.error("Tip de produs invalid.");
        return lista;
    }

    const produsNou = {
        id: nextId(lista),
        nume: numeCurat,
        stoc: stoc,
        disponibil: stoc > 0,
        tip: tip,
        categorie: categorie,
        utilizator: utilizator
    };

    return [...lista, produsNou];
}

// 6. Modifica stocul fara sa schimbe lista originala
function modificaStoc(lista, id, stocNou) {
    if (!Number.isInteger(stocNou) || stocNou < 0) {
        console.error("Stoc invalid.");
        return lista;
    }

    return lista.map(produs =>
        produs.id === id
            ? {
                ...produs,
                stoc: stocNou,
                disponibil: stocNou > 0
            }
            : produs
    );
}

// 7. Comuta disponibilitatea
function comutaDisponibilitate(lista, id) {
    return lista.map(produs =>
        produs.id === id
            ? {
                ...produs,
                disponibil: !produs.disponibil
            }
            : produs
    );
}

// 8. Sterge produs dupa ID
function stergeProdus(lista, id) {
    return lista.filter(produs => produs.id !== id);
}

// TESTE PENTRU ETAPA 2

console.log("--- Citire ---");
console.log("Produse:", listeazaProduse(produse).join(", "));
console.log("Disponibile:", numaraDisponibile(produse));
console.log(
    "Cautare suruburi:",
    listeazaProduse(cautaProduse(produse, "suruburi")).join(", ")
);

console.log("--- Adaugare ---");
let listaTest = adaugaProdus(
    produse,
    "Becuri LED",
    12,
    "consumabil",
    "Electronice",
    "admin"
);

console.log("Lista noua:", listaTest.length, "produse");
console.log("Lista originala:", produse.length, "produse");

console.log("--- Modificare stoc ---");
listaTest = modificaStoc(listaTest, 1, 10);
console.log(
    "Stoc nou pentru Suruburi M8:",
    listaTest.find(produs => produs.id === 1).stoc
);

console.log("--- Stergere ---");
listaTest = stergeProdus(listaTest, 3);
console.log("Produse ramase:", listeazaProduse(listaTest).join(", "));

console.log("--- Validare ---");
adaugaProdus(listaTest, "   ");
adaugaProdus(listaTest, "Produs invalid", 5, "urgent");
adaugaProdus(listaTest, "Produs cu stoc invalid", -1);
