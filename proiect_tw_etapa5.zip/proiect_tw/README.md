# DepoTrack

DepoTrack este o aplicație web pentru gestionarea produselor dintr-un depozit.
Aplicația permite organizarea și urmărirea disponibilității produselor.

## Sample data

1. Șuruburi M8, disponibile, Materie primă
2. Cutii de carton, indisponibile, Consumabil
3. Motoare electrice, disponibile, Produs finit

## How to run

Deschide `index.html` într-un browser.

## AI usage

ChatGPT a fost folosit pentru sprijin în realizarea interfeței HTML și CSS.

## Status

- [x] Stage 1: static mockup
- [ ] Stage 2: data logic in JavaScript