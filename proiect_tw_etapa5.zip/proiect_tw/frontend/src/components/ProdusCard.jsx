const ETICHETE_TIP = {
  "materie-prima": "Materie primă",
  "consumabil": "Consumabil",
  "produs-finit": "Produs finit"
};

export default function ProdusCard({ produs, onToggle, onDelete }) {
  return (
    <li className={produs.disponibil ? "produs-card" : "produs-card indisponibil"}>
      <label className="task-main">
        <input
          type="checkbox"
          checked={produs.disponibil}
          onChange={() => onToggle(produs.id)}
        />
        <div className="produs-info">
          <h3>{produs.nume}</h3>
          <span className={`badge badge-${produs.tip}`}>
            {ETICHETE_TIP[produs.tip] || produs.tip}
          </span>
          <p className="produs-detalii">
            Categorie: {produs.categorie} | Stoc: {produs.stoc} buc.
          </p>
        </div>
      </label>

      <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
        {/* Aici se afișează dinamic textul în funcție de starea de disponibilitate */}
        <span className={produs.disponibil ? "status disponibil" : "status indisponibil"}>
            {produs.disponibil ? "Disponibil" : "Indisponibil"}
        </span>
        <button
          className="btn-danger"
          onClick={() => onDelete(produs.id)}
          aria-label={`Șterge ${produs.nume}`}
        >
          Șterge
        </button>
      </div>
    </li>
  );
}