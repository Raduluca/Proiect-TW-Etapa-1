import { useState } from "react";
import ProdusList from "./components/ProdusList.jsx";
import "./App.css";

const PRODUSE_INITIALE = [
  {
    id: 1,
    nume: "Șuruburi M8",
    stoc: 3,
    disponibil: true,
    tip: "materie-prima",
    categorie: "Hardware",
    utilizator: "admin"
  },
  {
    id: 2,
    nume: "Cutii de carton",
    stoc: 1,
    disponibil: true,
    tip: "consumabil",
    categorie: "Ambalaje",
    utilizator: "admin"
  },
  {
    id: 3,
    nume: "Motoare electrice",
    stoc: 3,
    disponibil: true,
    tip: "produs-finit",
    categorie: "Electronice",
    utilizator: "admin"
  }
];

function temaInitiala() {
  return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

export default function App() {
  const [produse, setProduse] = useState(PRODUSE_INITIALE);
  const [tema, setTema] = useState(temaInitiala);

  function handleToggle(id) {
  setProduse((prev) =>
    prev.map((p) => (p.id === id ? { ...p, disponibil: !p.disponibil } : p))
  );
}

 function handleDelete(id) {
  setProduse((prev) => prev.filter((p) => p.id !== id));
}
  function handleTema() {
    const noua = tema === "dark" ? "light" : "dark";
    setTema(noua);
    document.documentElement.dataset.theme = noua;
  }

  const disponibile = produse.filter((p) => p.disponibil || p.stoc > 0).length;

  return (
    <>
      <header className="app-header">
        <button
          className="theme-toggle"
          onClick={handleTema}
          aria-pressed={tema === "dark"}
        >
          {tema === "dark" ? "Mod luminos" : "Mod întunecat"}
        </button>
        <h1>DepoTrack</h1>
        <p>Gestionarea stocurilor și produselor din depozit.</p>
        <p className="app-count">
          {produse.length} produse, dintre care {disponibile} disponibile
        </p>
      </header>

      <main className="container">
        <section className="panel">
          <h2>Produsele din depozit</h2>
          <ProdusList
            produse={produse}
            onToggle={handleToggle}
            onDelete={handleDelete}
          />
        </section>
      </main>
    </>
  );
}