# Jurnal AI - Etapa 1

## Instrumente

- ChatGPT

## Conversații

- <https://chatgpt.com/c/6ac7dc32-ba58-83ed-81d0-d3abdf2ea54a> (structura HTML/CSS și cerințele Etapei 1)

## Solicitări principale

### 1. Tema aplicației - gestionarea unui depozit

- Am cerut: Utilizarea unui sistem de gestionare a unui depozit de mărfuri ca temă a proiectului și adaptarea Etapei 1 la cerințele din ghidul de curs.
- Am primit: O structură de proiect bazată pe o listă de produse din depozit, cu numele produsului, starea de disponibilitate, tipul fix al produsului, categoria și utilizatorul.
- Am modificat sau respins: Designul final a fost adaptat pentru domeniul gestionării unui depozit și nu copiază exemplul TaskFlow.

### 2. Interfața HTML și CSS

- Am cerut: Crearea interfeței statice pentru Etapa 1 conform cerințelor din ghid.
- Am primit: HTML semantic folosind header, main, section, form, ul/li și footer, împreună cu CSS Grid, Flexbox, design responsive, focus vizibil și temă întunecată.
- Am modificat sau respins: Numele aplicației, etichetele, produsele de test și tipurile de produse au fost înlocuite cu elemente specifice unui sistem de gestionare a unui depozit.

### 3. README și documentația proiectului

- Am cerut: Pregătirea fișierului README și a jurnalului AI pentru Etapa 1, conform cerințelor din ghid.
- Am primit: Un README care conține modelul de date, datele de test, instrucțiunile de rulare și secțiunea privind utilizarea AI, precum și un jurnal AI pentru această etapă.
- Am modificat sau respins: Linkul către conversația ChatGPT trebuie adăugat manual după partajarea conversației.

## Ce am învățat / ce nu a funcționat

Pagina poate fi construită în întregime folosind HTML și CSS în Etapa 1; JavaScript nu este necesar încă.

CSS Grid este folosit pentru aranjarea celor două coloane pe desktop, iar Flexbox este folosit pentru formular și cardurile produselor.

Regula responsive schimbă structura paginii într-o singură coloană atunci când lățimea ecranului este mai mică de 700px.

Tema întunecată poate fi implementată prin modificarea variabilelor CSS, fără duplicarea regulilor de stil.